package páginas;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage { // Estes são os primeiros principios do page object.
    private WebDriver navegador; // Primeiro: Tenha um atributo da classe que seja do WebDrive.
    // Segundo: Tenha um construtor da classe que pegue um atributo / navegador de fora e jogue neste navegador.
    public LoginPage(WebDriver navegador) {
        this.navegador = navegador;
    }

    public LoginPage informarOUsername(String username) {
        navegador.findElement(By.cssSelector("label[for='username']")).click();
        navegador.findElement(By.id("username")).sendKeys(username);
        // sendKeys(username), a informação de quem é o username passa a ser dinâmica e não mais fixa.

        return this;
    }

    public LoginPage informarAPassword(String password) {
        navegador.findElement(By.cssSelector("label[for='password']")).click();
        navegador.findElement(By.id("password")).sendKeys(password);

        return this;
    }


   public ListaDeProdutosPage submeterFormularioDeLogin() {
       navegador.findElement(By.cssSelector("button[type='submit']")).click();

       return new ListaDeProdutosPage(navegador);
  }



}
