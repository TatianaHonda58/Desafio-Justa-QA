package páginas;


import com.sun.deploy.cache.DeployCacheHandler;
import com.sun.javafx.geom.Curve;
import org.junit.jupiter.api.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.time.Duration;

@DisplayName("Testes Web do Modulo de Produtos")

public class ProdutosTest {

    private static int produtos;
    private final Curve input;
    private WebDriver navegador;

    @BeforeEach
    public void beforeEach() {
        // Abrir o navegador
        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
        this.navegador = new ChromeDriver();

        // Vou maximizar a tela
        this.navegador.manage().window().maximize();

        // Vou definir um tempo de espera padrao de 5 segundos
        this.navegador.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Navegar para a página da Saucedemo
        this.navegador.get("https://www.saucedemo.com/");
    }
    @Test
    @DisplayName("Posso adicionar produto camisa vermelha")
        public void testPossoAdicionarProdutoCamisaVermelha() {

            // Fazer login
        String mensagemApresentada = new LoginPage(navegador)
                .informarOUsername("standard_user")
                .informarAPassword("secret_sauce")
                .submeterFormularioDeLogin()
                .capturarMensagemApresentada();


        Assertions.assertEquals("A compra da camisa vermelha foi efetuada.", mensagemApresentada);
    }


@Test
@DisplayName("Posso adicionar produto bolsa")
        public void testPossoAdicionarProdutoBolsa()  {
        String mensagemApresentada = new LoginPage(navegador)
        .informarOUsername("standard_user")
        .informarAPassword("secret_sauce")
        .submeterFormularioDeLogin()
        .capturarMensagemApresentada();

        // Produto adiconado com sucesso
        Assertions.assertEquals("A compra da bolsa foi efetuada.", mensagemApresentada);
    }
@Test
@DisplayName("Posso adicionar dois produtos com valores menores")
public void testPossoAdicionarDoisProdutosComValoresMenores()  {
        String mensagemApresentada = new LoginPage(navegador)
        .informarOUsername("standard_user")
        .informarAPassword("secret_sauce")
        .submeterFormularioDeLogin()
        .capturarMensagemApresentada();

        // Produto adicionado com sucesso
        Assertions.assertEquals("Produtos com valores menores foi efetuada.", mensagemApresentada);
        }

    // Teste:
    public String ProdutosTest(Curve input) {
        this.input = input;
        boolean comprarProduto;
        if (comprarProduto > 0) {
            System.out.println("Clique no botão do produto: \n");

            System.out.println("--------Produtos disponíveis--------");
            for (ProdutosTest p : comprarProduto())  {
                System.out.println(p + "\n");
            }

            int id = Integer.parseInt(this.input.next());
            boolean isPresent = false;

            ProdutosTest[] comprarProduto;
            for (ProdutosTest p : comprarProduto) {
                if (p.getId() == id) {
                    int quantidade = 0;
                    DeployCacheHandler carrinho;
                    try {
                        quantidade = carrinho.get(p);
                        carrinho.put(produtos,quantidade + 1);
                    } catch (NullPointerException e) {
                        //se o produto for o primeiro no carrinho
                        carrinho.put(produtos,1);
                    }
                    System.out.println(p.getNome() + "adicionado ao carrinho.");
                    isPresent = true;

                    if (isPresent) {
                        System.out.println("Deseja adicionar outro produto ao carrinho? ");
                        System.out.println("Clique no produto para finalizar a compra. \n");
                        int option = Integer.parseInt(this.input.next());

                        if (option == 1) {
                            comprarProduto();

                        } else {
                            return("Compra finalizada.");
                        }
                    }
                } else {
                    System.out.println("Produto não encontrado.");
                    return("produto");
                }
            }
        }
    }

    public int comprarProduto() {
        return comprarProduto();
    }

    public int getId() {
        return getId();
    }


    public static void verCarrinho() {
        System.out.println("Produtos no seu carrinho");
        if(carrinho.size() > 0) {
            
            for(ListaDeProdutosPage p: carrinho.set());
                System.out.println("Produto: " + p + "\nQuangetidade: " + carrinho.get(produtos));
        }
    }

@AfterEach
    public void afterEach() {
        // Vou fechar o navegador
        navegador.quit();
    }

    // Não existe uma sequência de execução no JUnit, independencia dos testes.

    public String getNome() {
        return getNome();
    }
}
